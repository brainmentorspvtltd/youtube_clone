// Stateless
// StateFul

import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          Icon(Icons.search),
          SizedBox(
            width: 20,
          ),
          Icon(Icons.cast),
          SizedBox(
            width: 20,
          )
        ],
        leading: Icon(Icons.menu),
        backgroundColor: Colors.red,
        title: Text('YouTube App 2023'),
      ),
      body: SingleChildScrollView(
        child: Container(
          height: 500,
          //margin: EdgeInsets.all(50),
          child: Column(mainAxisAlignment: MainAxisAlignment.start, children: [
            Expanded(child: Image.network('https://i.gifer.com/5XQl.gif')),
            // SizedBox(
            //   height: 30,
            // ),
            Expanded(
              child: Image.network(
                  'https://phoneky.co.uk/thumbs/screensavers/down/movies/spiderman_35164ixz.gif'),
            ),
          ]),
          // child: Text(
          //   'Hello Flutter',
          //   style: TextStyle(fontSize: 30),
          // ),
        ),
      ),
    );
  }
}
