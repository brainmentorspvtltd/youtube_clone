import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:youtube_clone/pages/home.dart';

void main() {
  // Flutter - Widgets
  runApp(MaterialApp(home: Home()));
}
