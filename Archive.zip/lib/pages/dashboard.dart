import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:youtubeapp_clone/pages/home.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  AppBar _buildAppBar() {
    return AppBar(
      actions: const [
        Icon(
          Icons.search,
          color: Colors.black,
        ),
        SizedBox(
          width: 30,
        ),
        Icon(
          Icons.cast,
          color: Colors.black,
        ),
        SizedBox(
          width: 30,
        )
      ],
      elevation: 0,
      backgroundColor: Colors.transparent,
      title: SizedBox(
        height: 100,
        child: Image.network(
          'https://cdn.iconscout.com/icon/free/png-256/free-youtube-86-226404.png',
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  _buildScreens() {
    return [Home(), Text('Subscriptions'), Text('Library')];
  }

  _buildTabs() {
    return const [
      BottomNavigationBarItem(
          icon: Icon(
            Icons.home,
          ),
          label: 'Home'),
      BottomNavigationBarItem(
          icon: Icon(Icons.subscriptions), label: 'Subscriptions'),
      BottomNavigationBarItem(icon: Icon(Icons.library_add), label: 'Library')
    ];
  }

  int index = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _buildScreens()[index],
      appBar: _buildAppBar(),
      bottomNavigationBar: BottomNavigationBar(
        items: _buildTabs(),
        currentIndex: index,
        onTap: (int currentIndex) {
          index = currentIndex;
          setState(() {});
        },
      ),
    );
  }
}
