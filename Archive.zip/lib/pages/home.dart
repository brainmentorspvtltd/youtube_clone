import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:youtubeapp_clone/pages/player.dart';
import 'package:youtubeapp_clone/services/api_client.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  ApiClient _apiClient = ApiClient();
  @override
  Widget build(BuildContext context) {
    return Container(
        child: FutureBuilder(
            future: _apiClient.getVideos(),
            builder: (c, AsyncSnapshot snapshot) {
              if (!snapshot.hasData) {
                return Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(
                  child: Text('Something went Wrong..'),
                );
              } else {
                return ListView.builder(
                  itemBuilder: (e, int index) {
                    return InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) =>
                                Player(snapshot.data['items'][index]['id'])));
                      },
                      child: Image.network(snapshot.data['items'][index]
                          ['snippet']['thumbnails']['high']['url']),
                    );
                  },
                  itemCount: snapshot.data.length,
                );
              }
            }));
  }
}
