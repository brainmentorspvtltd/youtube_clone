import 'package:flutter/material.dart';
import 'package:youtubeapp_clone/pages/dashboard.dart';

void main() {
  runApp(MaterialApp(
    home: Dashboard(),
  ));
}
