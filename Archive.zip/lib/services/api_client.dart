// Do Network Call
import 'package:dio/dio.dart';

class ApiClient {
  Dio _dio = Dio();
  getVideos() async {
    Response response = await _dio.get(
        'https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics%2Cplayer&chart=mostPopular&maxResults=100&regionCode=IN&key=AIzaSyBj26XzfBPpLSblkySaj-freAshWMMYnxQ');
    print("Response ");
    print(response);
    print(response.runtimeType);
    return response.data;
  }
}
